Taylor Foxhall
tfoxhal1@binghamton.edu
B00433498
