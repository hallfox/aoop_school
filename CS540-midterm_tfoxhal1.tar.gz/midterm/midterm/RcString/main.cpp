#include "RcString.hpp"

using namespace cs540;

int
main() {

    RcString s1; // Initialize to "".

    // After the below, s2 and s1 should point to the same data object.
    RcString s2(s1);

    RcString s3;
    s3 = s1; // After this, also point to same data object.

    RcString s4("hello");

    RcString s5(std::string("hello"));

    // Output.
    std::cout << s5 << std::endl;

    // Concatentation.
    {
        RcString s1("hello ");
        RcString s2("goodbye");
        RcString s3(s1 + s2); // Invoke move ctor.
        std::cout << s3 << std::endl;

        RcString s4;
        s4 = s3 + " forever."; // Move assignment.
        std::cout << s4 << std::endl;
    }
}
