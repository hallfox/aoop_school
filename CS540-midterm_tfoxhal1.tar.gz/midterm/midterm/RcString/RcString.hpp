/*
 * This is a reference counted string implementation.  Two RcString objects
 * that have a common ancestor and contain the original string should point to
 * the same data object.  This provides very fast copies.
 *
 * You are not allowed to use std::string in this.
 */



#ifndef CS540_RC_STRING_HPP
#define CS540_RC_STRING_HPP

#include <string.h>
#include <iostream>


namespace cs540 {


class RcString {
    private:
        struct RcString_data {
          friend class RcString;
          RcString_data() = delete;
          RcString_data(const char *s): str_{strdup(s)}, ref_count{1} {}
          ~RcString_data() {
            free(str_);
          }
          char *str_;
          int ref_count;
        };
    public:
        // Public methods.
        RcString(): m_data{new RcString_data{""}} {}
        RcString(const RcString& rcstr) {
          m_data = rcstr.m_data;
          m_data->ref_count++;
        }
        RcString& operator=(const RcString& rcstr) {
          if (&rcstr == this) {
            return *this;
          }

          if (this->m_data == rcstr.m_data) {
            this->m_data = rcstr.m_data;
          } else {
            if (--m_data->ref_count == 0) {
              delete m_data;
            }
            this->m_data = rcstr.m_data;
            this->m_data->ref_count++;
          }
          return *this;
        }
        RcString(const char *s): m_data{new RcString_data{s}} {}
        RcString(const std::string& s): m_data{new RcString_data{s.c_str()}} {}
        ~RcString() {
            // Delete the data object if the ref count goes to 0.
            if (--m_data->ref_count == 0) {
                delete m_data;
            }
        }
        RcString(const RcString&& rcstr) {
          this->m_data = std::move(rcstr.m_data);
        }
        RcString& operator=(const RcString&& rcstr) {
          if (&rcstr == this) {
            return *this;
          }
          this->m_data = std::move(rcstr.m_data);

          return *this;
        }
        friend std::ostream& operator<<(std::ostream& os, const RcString& rcstr);
        RcString operator+(const RcString& other) {
          char *new_str = new char[strlen(this->m_data->str_) + strlen(other.m_data->str_) + 1];
          strcpy(new_str, this->m_data->str_);
          strcat(new_str, other.m_data->str_);
          return RcString(new_str);
        }
        RcString operator+(const char *other) {
          char *new_str = new char[strlen(this->m_data->str_) + strlen(other) + 1];
          strcpy(new_str, this->m_data->str_);
          strcat(new_str, other);
          return RcString(new_str);
        }
    private:
        RcString_data *m_data;
};

std::ostream& operator<<(std::ostream& os, const RcString& rcstr) {
  os << rcstr.m_data->str_;
  return os;
}


}



#endif
